<?php
/**
* 
*/
class foodsType extends AnotherClass
{
	var $id,$code,$typename,$active,$remark;
	function __construct(argument)
	{
		# code...
		$id="";
		$code="";
		$typename="";
		$active="";
		$remark="";
	}
}

?>
