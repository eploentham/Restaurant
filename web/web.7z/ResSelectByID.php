<?php
//include "connectdb.inc.php";

//$conn = new ConnectDB();
$resultArray = array();
//$resultArray["area"] = array();
$objConnect = mysql_connect("localhost","root","Ekartc2c5");
$objDB = mysql_select_db("restaurant");
mysql_query("SET NAMES UTF8");
$objQuery = mysql_query("Select * From b_restaurant Where res_id = '".$_POST['res_id']."'");
$intNumField = mysql_num_fields($objQuery);
while($row = mysql_fetch_array($objQuery)){
	//$arrCol = array();
	$tmp = array();
    $tmp["res_id"] = $row["res_id"];
    $tmp["res_code"] = $row["res_code"];
    $tmp["res_name"] = $row["res_name"];
    $tmp["active"] = $row["active"];
    //$tmp["sort1"] = $row["sort1"];
    $tmp["remark"] = $row["remark"];
    //$tmp["area_id"] = $row["area_id"];
   
	array_push($resultArray,$tmp);
}
mysql_close($objConnect);
	//$pid = $_POST['order_id'];
	//$name = $_POST['foods_code'];
	//$price = $_POST['price'];
	//$description = $_POST['description'];
	//$conn->getArea();
header('Content-Type: application/json');
echo json_encode($resultArray);
?>