<?php
//include "connectdb.inc.php";

//$conn = new ConnectDB();
$resultArray = array();
//$resultArray["area"] = array();
$objConnect = mysql_connect("localhost","root","Ekartc2c5");
$objDB = mysql_select_db("restaurant");
mysql_query("SET NAMES UTF8");
//$objQuery = mysql_query("Select * From t_bill Where active = '1' and bill_code = '".$_POST['bill_code']."' ");
$objQuery = mysql_query("Select sum(amount) as amt, sum(discount) as discount, su,(total) as total, sum(service_charge) as sc, sum(vat) as vat, sum(nettotal) as nettotal, count(1) as cnt_bill From t_bill Where status_closeday <> '1' and active = '1' ");
$intNumField = mysql_num_fields($objQuery);
while($row = mysql_fetch_array($objQuery)){
    //$arrCol = array();
    $tmp = array();
    $tmp["amt"] = $row["amt"];
    $tmp["discount"] = $row["discount"];
    $tmp["total"] = $row["total"];
    $tmp["sc"] = $row["sc"];
    $tmp["vat"] = $row["vat"];
    $tmp["nettotal"] = $row["nettotal"];
    $tmp["cnt"] = $row["cnt"];
    
    array_push($resultArray,$tmp);
}
mysql_close($objConnect);

header('Content-Type: application/json');
echo json_encode($resultArray);

	//$pid = $_POST['order_id'];
	//$name = $_POST['foods_code'];
	//$price = $_POST['price'];
	//$description = $_POST['description'];
	//$conn->getArea();

?>