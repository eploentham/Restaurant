<html>
<body>
<?php
echo phpinfo();
?>
<body>
<html>
